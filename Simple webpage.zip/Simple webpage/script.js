function learnMore() {
    alert("Practice Every day can lead to become a developer");
}

document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Thank you for contacting us! We will get back to you shortly.");
});
